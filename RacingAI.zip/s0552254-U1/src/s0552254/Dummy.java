package s0552254;

import lenz.htw.ai4g.ai.AI;
import lenz.htw.ai4g.ai.DriverAction;
import lenz.htw.ai4g.ai.Info;

public class Dummy extends AI {

	public Dummy(Info info) {
		super(info);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return "Dummy";
	}

	@Override
	public DriverAction update(boolean arg0) {
		// TODO Auto-generated method stub
		return new DriverAction(0,0);
	}

}
