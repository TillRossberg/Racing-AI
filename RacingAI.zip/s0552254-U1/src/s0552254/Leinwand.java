package s0552254;

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Point2D;

public class Leinwand 
{

   private Frame mainFrame;
   private Label headerLabel;
   private Label statusLabel;
   private Panel controlPanel;

   //Rahmengr��en
   private int width = 1100;
   private int height = 1100;
   
   //A*
   AStern myAStern;
   Graph myGraph;
   
   public Leinwand(AStern astern, Graph graph)
   {
      prepareGUI();
      myAStern = astern;
      myGraph = graph;
   }


   private void prepareGUI()
   {
      mainFrame = new Frame("A* Algorithm");
      mainFrame.setSize(width + 100, height + 100);
//      mainFrame.setLayout(new GridLayout(3, 1));
      
      mainFrame.addWindowListener(new WindowAdapter() 
      {
         public void windowClosing(WindowEvent windowEvent)
         {
            System.exit(0);
         }        
      });    
//      headerLabel = new Label();
//      headerLabel.setAlignment(Label.CENTER);
//      statusLabel = new Label();        
//      statusLabel.setAlignment(Label.CENTER);
//      statusLabel.setSize(350,100);
//
//	    controlPanel = new Panel();
//	    controlPanel.setLayout(new FlowLayout());
//
//      mainFrame.add(headerLabel);
//	    mainFrame.add(controlPanel);
//      mainFrame.add(statusLabel);
	    mainFrame.setVisible(true);  
   }

   public void showCanvasDemo()
   {
//      headerLabel.setText("Control in action: Canvas"); 

      mainFrame.add(new MyCanvas());
      mainFrame.setVisible(true);  
   } 

   class MyCanvas extends Canvas 
   {

      public MyCanvas () 
      {
         setBackground (Color.WHITE);
         setSize(400, 400);
      }

      public void paint (Graphics g) 
      {
         Graphics2D g2;    
         //Rahmen malen
         g.setColor(Color.BLACK);
         g.drawLine(0, 0, 0, height);
         g.drawLine(0, 0, width, 0);
         g.drawLine(width, 0, width, height);
         g.drawLine(0, height, width, height);
//       drawGrid(g);
         drawGraph(g);
         
         
         
         
      }
      
      //Den Graphen zeichnen.
      public void drawGraph(Graphics g)
      {
    	  int vertexRadius = 10;
    	  //Edges
    	  for(int vertex = 0; vertex < myGraph.getEdges().size(); vertex++)
    	  {
    		  for(int edge = 0; edge < myGraph.getEdges().size(); edge++)
        	  {
        		  if(myGraph.getEdges().get(vertex).get(edge) > 0)
        		  {
        			  //Edges malen.
        			  g.setColor(Color.BLACK);
//        			  if(myGraph.getVertices().get(edge).isPartOfFinalPath()){g.setColor(Color.blue);}        				  
        			  Point2D.Float start = new Point2D.Float(myGraph.getVertices().get(vertex).getPosition().x, height -myGraph.getVertices().get(vertex).getPosition().y);
        			  Point2D.Float end = new Point2D.Float(myGraph.getVertices().get(edge).getPosition().x,height - myGraph.getVertices().get(edge).getPosition().y);
        			  g.drawLine((int)(start.x),(int)(start.y),(int)(end.x),(int)(end.y));
        			  
        			  //Kantengewicht an die Edges malen.
        			  Point2D.Float mitteZwischenStartEnd = new Point2D.Float((end.x - start.x)/2, (end.y - start.y)/2);   
        			  g.setColor(Color.BLACK);
        			  g.drawString("Gewicht: " + myGraph.getEdges().get(vertex).get(edge), (int)(start.x + mitteZwischenStartEnd.x),(int)(start.y + mitteZwischenStartEnd.y));
        		  }
        	  }
    	  }
    	  //Vertices
    	  for (int i = 0; i < myGraph.getVertices().size(); i++)
    	  {
    		   //Punkte malen.
    		   g.setColor(Color.red);
    		   Point2D.Float thisPoint = myGraph.getVertices().get(i).getPosition();
    		   if(myGraph.getVertices().get(i).isPartOfFinalPath()){g.setColor(Color.blue);}
    		   if(myGraph.getVertices().get(i).isStartPoint()){g.setColor(Color.green);}
    		   if(myGraph.getVertices().get(i).isEndPoint()){g.setColor(Color.green);}
    		   
    		   g.fillOval((int)(thisPoint.x) - vertexRadius/2,height - (int)(thisPoint.y) - vertexRadius/2, vertexRadius, vertexRadius);
    		   
    		   //Nummer des Punktes malen.
    		   g.setColor(Color.BLACK);
    		   g.drawString("Punkt#" + i, (int)(thisPoint.x),height - (int)(thisPoint.y) -5);    		   
    	  }   	      	  
      }      
   }
}