package s0552254;

import java.awt.geom.Point2D;
import java.util.ArrayList;

public class AStern 
{
		//Start und Endpunkt.
		private Vertex startPunkt;		
		private Vertex endPunkt;
		//Shortest path from start to end
		private ArrayList<Vertex> finalPath = new ArrayList<Vertex>();
		
		//These nodes still have to be evaluated.
		private ArrayList<Vertex> openSet = new ArrayList<Vertex>();
		
		//All the nodes, that have been visited.
		private ArrayList<Vertex> closedSet = new ArrayList<Vertex>();
				
		//Graph
		ArrayList<Vertex> myVertices;
		ArrayList<ArrayList<Float>> myEdges;
		
	//Konstruktor
	public AStern()
	{
	//Initalisierung		
		
	}
		
	//Zum initialisieren.
	public void setup()
	{			
			
	}	

	
	//-------------------------------------------------------------------------------------------------------------------------
	//Hauptfunktion
	public void aStarAlgorithm(Vertex start, Vertex end, ArrayList<Vertex> vertices, ArrayList<ArrayList<Float>> edges)
	{
		myVertices = vertices;
		myEdges = edges;
		//resets
		openSet.clear();
		closedSet.clear();
		finalPath.clear();
		resetAllNodes();
		
		//Initalisierung	
		startPunkt = start;
		start.setIsStartPoint(true);
		endPunkt = end;
		end.setIsEndPoint(true);
		openSet.add(startPunkt);
		
		//Hauptfunktion
		boolean finished = false;		
		while (!finished)
		{
			if(openSet.size() > 0)
			{
			//We can keep going
				//Check who has the lowest fCost in the openSet and make em the current.
				int winner = 0;
				for(int i = 1; i < openSet.size(); i++)
				{
					if(openSet.get(i).getF() < openSet.get(winner).getF())
					{
						winner = i;						
					}
				}
				//Sprung zum Gewinner des gro�en f-Score-Wettbewerbs.
				Vertex current = openSet.get(winner);
//				System.out.println(openSet.get(winner).getSpotNumber());
				//When the winner of the last iteration is the end node, we are done.
				if(current == endPunkt)
				{
					System.out.println("Weg gefunden!");
					//Weg rekonstruieren.
					finalPath = reconstructPath(current);
					reverse(finalPath);
					printFinalPath();
					start.setIsStartPoint(false);
					end.setIsEndPoint(false);
					finished = true;
				}
				
				openSet.remove(winner);
				closedSet.add(current);		
				//Alle Nachbarn von current evaluieren.
				ArrayList<Vertex> neighbors = current.getNeighbors();
				for(Vertex neighbor : neighbors)
				{					
					//Wenn der Nachbar schon im closedSet ist, nicht evaluieren!
					if(!closedSet.contains(neighbor))
					{
						//gScore evaluieren	
						//Kantengewicht entspricht dem Eintrag in 'edges' von currentSpotNumber gefolgt von neighborSpotnumber. 
						float tempGScore = (current.getG() + myEdges.get(current.getSpotNumberAsInt()).get(neighbor.getSpotNumberAsInt()));
//						System.out.println("Vertex: " + current.getSpotNumberAsInt() + "; Edge: " + current.getSpotNumberAsInt() + "; CurrentG: " + current.getG() + "; neighborG: " + myEdges.get( (int) (current.getSpotNumber()) ).get( (int) (neighbor.getSpotNumber()))) ;
								
						//Irgendwas mit schonmal besucht und vielleicht als besser befunden... H�H?
						if(!openSet.contains(neighbor))
						{
							openSet.add(neighbor);
							neighbor.setG(Float.POSITIVE_INFINITY);
						}
							//Wenn wir schon einen besseren gScore haben, wird der nicht ersetzt, aber woher wissen wir von wo aus wir diesen gScore berechnet haben?
							if(tempGScore < neighbor.getG())
							{
								neighbor.setG(tempGScore);
								//Heuristik berechnen.
								neighbor.setH(calcDistance(neighbor.getPosition(), endPunkt.getPosition()));
								
								//fScore berechnen.
								neighbor.setF(neighbor.getG() + neighbor.getH());
								//Vorhergehenden Knoten f�r den Nachbarn festlegen.
								neighbor.setPreviousNode(current);			
							}	
						
						
														
					}
				}
			}
			else
			{
				//No way was found
				System.out.println("Couldn't find a path! ");				
				finished = true;			
			}						
		}		
	}
	
	//Additional functions
	
	//Finalen Pfad in der Konsole ausgeben.
	public void printFinalPath()
	{
		System.out.println("Finaler Pfad: ");
		for(int i = 0; i < finalPath.size(); i++)
		{
			System.out.print(finalPath.get(i).getSpotNumber() + ", ");
		}
		System.out.println("");
	}
	
	//Berechnet den euklidischen Abstand zwischen Start- und Endpunkt.
	public float calcDistance(Point2D.Float start, Point2D.Float end)
	{
		float differenceX = end.x - start.x;
		float differenceY = end.y - start.y;
		float distance = (float) Math.sqrt(Math.pow(differenceX, 2) + Math.pow(differenceY, 2));
		return distance;	
	}
	
	//Entfernt alle previous Nodes. Sonst werden nodes ber�cksichtigt, die bei vorangegangenen A*-Ausf�hrungen genutzt wurden und dat wolln wir nich!
	public void resetAllNodes()
	{
		for(int i = 0; i < myVertices.size(); i++)
		{
			myVertices.get(i).removePreviousNode();
			myVertices.get(i).setF(0f);
			myVertices.get(i).setG(0f);
			myVertices.get(i).setH(0f);
		}
	}
	//Pfad rekonstruieren
	public ArrayList<Vertex> reconstructPath(Vertex myCurrentVertex)
	{
		ArrayList<Vertex> path = new ArrayList<Vertex>();
		path.add(myCurrentVertex);
		myCurrentVertex.setPartOfFinalPath(true);
		//Solange myCurrentVertex eine previous Node hat, wird diese dem finalPath hinzugef�gt.
		while(myCurrentVertex.getPreviousNode() != null)
		{			
			path.add(myCurrentVertex.getPreviousNode());
			//Ist n�tig, damit die previousNode wieder entfernt werden kann. Sonst werden nodes ber�cksichtigt, die bei vorangegangenen A*-Ausf�hrungen genutzt wurden und dat wolln wir nich!
			myCurrentVertex = myCurrentVertex.getPreviousNode();			
			myCurrentVertex.setPartOfFinalPath(true);
		}	
		return path;	
	}

	//ArrayList invertieren.
	public ArrayList<Vertex> reverse(ArrayList<Vertex> myList) 
	{
	    for(int i = 0, j = myList.size() - 1; i < j; i++) 
	    {
	        myList.add(i, myList.remove(j));
	    }
	    return myList;
	}
	
	//Printfunctions
	
	
	//Getters and Setters	
	public ArrayList<Vertex> getFinalPath() {return finalPath;}
}
