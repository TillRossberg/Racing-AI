package s0552254;

import java.awt.Polygon;

import lenz.htw.ai4g.ai.AI;
import lenz.htw.ai4g.ai.DriverAction;
import lenz.htw.ai4g.ai.Info;
//import s0552254.Leinwand;

import java.awt.geom.Point2D;
import java.nio.file.WatchService;
import java.util.ArrayList;
import java.util.Vector;

import org.lwjgl.opengl.GL11;
import org.lwjgl.util.vector.Vector2f;

public class ChefKlasse extends AI 
{
	Graph myGraph;
	AStern myAStern;
//	Leinwand myLeindwand;
	private float acceleration = 1f; //0-1
	private float direction = 0;//1 links, -1 rechts	
	private float seekDirection = 0;
	private float a = 1;//Gewichtung f�r seek
	private float fleeDirection = 0;
	private float b = 0;//Gewichtung f�r flee
		
	//Koordinaten
	private Point2D.Float autoPos = new Point2D.Float(0, 0);	
	private Point2D.Float checkPointPos = new Point2D.Float(0, 0);	
	private Point2D.Float myTargetPos = new Point2D.Float(0, 0);//aktuelles Ziel
	private Vertex start;
	private Vertex end;
	private float richtungX;
	private float richtungY;
	private float checkPointAbstand;
	
	//Abst�nde
	private float currentTargetDistance; //Abstand zur n�chsten node des final path.
	private float toleranzRadius = 20f; //Ab diesem Abstand soll der Punkt als erreicht gelten.
	
	//Hindernisse, Fast- und Slowzones
	Polygon[] obstacles = info.getTrack().getObstacles();	
	Polygon[] fastZones = info.getTrack().getFastZones();
	Polygon[] slowZones = info.getTrack().getSlowZones();
	
	
	private float radiusHindernis = 50;
	float kleinsterAbstand = 100;
	float abstandZumHindernis;
	float richtungsVektorHindernisX;
	float richtungsVektorHindernisY;
	float aktuellesHindernisX = 100;
	float aktuellesHindernisY = 100;
	float deltaWinkelHindernis = 1;
	float hindernisAusrichtung = 1;
	
	//Winkel	
	private float zielAusrichtung;
	private float eigeneAusrichtung;
	private float deltaWinkelCheckPoint;//Winkel zwischen eigener Ausrichtung und Zielausrichtung.
	
	//Debugzeuch
	private int timer = 0;
	private int counterFeinausrichtung;
	private boolean ausweichVerhaltenAktiv;
	
	//Knoten, die tats�chlich abgefahren werden sollen.
	ArrayList<Point2D.Float> readyPath = new ArrayList<Point2D.Float>();
	private Integer pfadIndex = 0;
	
	//Avoidstuff
	private int lengthFor;
    private int seperations = 10;
    private Vector2f vectorLeft;
    private Vector2f vectorMiddle;
    private Vector2f vectorRight;
	

	public ChefKlasse(Info info) 
	{
		super(info);
		
		//Graph
		myGraph = new Graph(obstacles, fastZones, slowZones);
		myGraph.createEmptyGraph();
		//F�r den ersten Durchlauf Auto- und Checkpointposition hinzuf�gen.
		autoPos.setLocation(info.getX(), info.getY());
		checkPointPos.setLocation(info.getCurrentCheckpoint());
		myGraph.addVertex(autoPos.x, autoPos.y);
		myGraph.addVertex(checkPointPos.x, checkPointPos.y);			
		
		myGraph.createPaths();		
//		myGraph.printNeighborsForAllVertices(myGraph.getVertices());
		myGraph.printAdjacencyMatrixForArrayList(myGraph.getEdges());
		
		//A*
		
		start = myGraph.getVertices().get(myGraph.getVertices().size()-2);
		end = myGraph.getVertices().get(myGraph.getVertices().size()-1);
		
		myAStern = new AStern();
		myAStern.aStarAlgorithm(start, end, myGraph.getVertices(), myGraph.getEdges());
//		refineObstacles();
//		myGraph.printVertices(myGraph.getVertices());
//		myAStern.aStarAlgorithm(testStart, testEnd );
//		myGraph.printVertices(myGraph.getVertices());
//		myGraph.printNeighborsForAllVertices(myGraph.getVertices());
		//Canvas
//		Leinwand  myLeinwand = new Leinwand(myAStern, myGraph);		
//		myLeinwand.showCanvasDemo();
	}

//	Eigene Textur einbauen (kommt einfach ins package rein)
//	@Override
//	public String getTextureResourceName() {
//		// TODO Auto-generated method stub
//		return "/s0552254/meineTextur.jpg;
//	}
	
	@Override
	public String getName() 
	{
		// TODO Auto-generated method stub
		return "Till";
	}
	
	public void doDebugStuff()
	{
		drawGraph();		
		drawFinalPath();		
		drawFastZonesNodes();
		drawSlowZonesNodes();	
		drawObstacleVertices();
		//Linie zum aktuellen Checkpoint zeichnen.
		GL11.glBegin(GL11.GL_LINES);
		GL11.glColor3d(1, 0, 0);
		GL11.glVertex2d(autoPos.x, autoPos.y);
		GL11.glVertex2d(checkPointPos.x, checkPointPos.y);
		GL11.glEnd();
		
		//Linie zum aktuellen Punkt des finalPath zeichnen.
		GL11.glBegin(GL11.GL_LINES);
		GL11.glColor3d(1, 1, 1);
		GL11.glVertex2d(autoPos.x, autoPos.y);
		GL11.glVertex2d(myAStern.getFinalPath().get(pfadIndex).getPosition().x, myAStern.getFinalPath().get(pfadIndex).getPosition().y);
		GL11.glEnd();
								
		//Geschwindigkeitsvektor einzeichnen
		GL11.glBegin(GL11.GL_LINES);
		GL11.glColor3d(0, 0, 1);
		GL11.glVertex2d(autoPos.x, autoPos.y);
		GL11.glVertex2d(autoPos.x + info.getVelocity().x, autoPos.y + info.getVelocity().y);
		GL11.glEnd();
	}

	
	

	@Override
	public DriverAction update(boolean resetAfterCollision) 
	{		
		//Standarwerte setzen
		acceleration = 1;
		direction = 0;
		a = 1;
		b = 0;
		//Die wichtigsten Koordinaten holen.
		autoPos.x = info.getX();
		autoPos.y = info.getY();		
		// �nderung des Checkpoint registrieren, dann Auto- und Checkpointposition dem Graphen hinzuf�gen und den A* erneut ausf�hren.
		checkIfCheckPointHasChanged();		
		//Wenn das Auto explodiert ist, den Pfadindex resetten.
		if(resetAfterCollision)
		{
			pfadIndex = 0;
		}
		
		//Abstand zur n�chste path node berechnen.
		currentTargetDistance = calculateDistance(autoPos, myTargetPos);
		//Pr�fen, ob der aktuelle Punkt des final path erreicht wurde, wenn dies der Fall ist, den n�chsten Punkt als aktuelles Ziel setzen.
		if(currentTargetDistance < toleranzRadius)
		{
//			System.out.println("Folgernder Punkt wurde erreicht: #" + pfadIndex + " X: " + myTargetPos.x + " Y: " + myTargetPos.y);
			if(pfadIndex < myAStern.getFinalPath().size()-1)
			{
				pfadIndex++;
			}			
		}
		
//		abstandZumHindernis =  (float) Math.sqrt(Math.pow(testHindernisX - autoX, 2) + Math.pow(testHindernisY - autoY, 2));
//		//Gewichtung berechnen				
//		if(abstandZumHindernis < radiusHindernis)
//		{
//			//Fleeverhalten
//			fleeDirection = -seek(testHindernisX,testHindernisY);
//			b = (radiusHindernis - abstandZumHindernis) / radiusHindernis;
//			a = 1 - b;
//		}
		
		myTargetPos.x = myAStern.getFinalPath().get(pfadIndex).getPosition().x;
		myTargetPos.y = myAStern.getFinalPath().get(pfadIndex).getPosition().y;
		
		//Seekverhalten
		seekDirection = seek(myTargetPos.x, myTargetPos.y);
		doAvoidingStuff();
		//Finale Richtung bestimmen.
		direction = (a * seekDirection + b * fleeDirection) / (a+b);
		
//		return new DriverAction(1, 0);
		return new DriverAction(acceleration, seekDirection);
	}	
	
	private void checkIfCheckPointHasChanged() 
	{
		if (info.getCurrentCheckpoint().getX() != checkPointPos.x && info.getCurrentCheckpoint().getY() != checkPointPos.y) 
		{
			System.out.println("Checkpoint changed!");
			//neuen Checkpoint als Ziel setzen
			checkPointPos.x = (float) info.getCurrentCheckpoint().getX();
			checkPointPos.y = (float) info.getCurrentCheckpoint().getY();
			//Alte Auto- und Checkpointposition aus dem Graphen entfernen.
//			myGraph.removeVertex(myGraph.getVertices().size() - 1);
//			myGraph.removeVertex(myGraph.getVertices().size() - 1);
			//Die Kanten auch noch entfernen
//			myGraph.clearCarTargetEdges();
//			//Die aktuelle Auto- und Checkpointposition hinzuf�gen.
			myGraph.addVertex(autoPos.x, autoPos.y);
			myGraph.addVertex(checkPointPos.x, checkPointPos.y);			
//			//Kanten neu kalkulieren, da Auto- und Checkpointposition hinzugekommen sind.
			myGraph.createPaths();
			myGraph.printAdjacencyMatrixForArrayList(myGraph.getEdges());
//			//A* ausf�hren
			start = myGraph.getVertices().get(myGraph.getVertices().size()-2);//Auto
			end = myGraph.getVertices().get(myGraph.getVertices().size()-1);//Checkpoint
			myAStern.aStarAlgorithm(start, end, myGraph.getVertices(), myGraph.getEdges());
			
//			//Pfadposition zur�cksetzen.
			pfadIndex = 0;			
		}
		
	}
	
	
	//Seek
	public float seek(float X, float Y)
	{
		//Richtungsvektor zum Checkpoint berechnen.
		autoPos.x = info.getX();
		autoPos.y = info.getY();
		Point2D.Float ziel = new Point2D.Float();
		ziel.setLocation(X, Y);		
		richtungX =	ziel.x - autoPos.x;
		richtungY = ziel.y - autoPos.y;
		
		
		//Ausrichtungen berechnen
		zielAusrichtung = (float) Math.atan2(richtungY, richtungX);
		eigeneAusrichtung = info.getOrientation();
		deltaWinkelCheckPoint = (zielAusrichtung - eigeneAusrichtung);
		
		winkelBegrenzen();
		//Abst�nde berechnen 
		checkPointAbstand =  (float) Math.sqrt(Math.pow(richtungX, 2) + Math.pow(richtungY, 2));
		
//		if(checkPointAbstand < 100)
//		{
//			System.out.println("100!");
//		}
		
		//Wenn der Checkpoint innerhalb des Toleranzbereich ist, gleiche die Lenkrichtung an.
		//45 Grad
		if(Math.abs(deltaWinkelCheckPoint) < 0.785)	
		{
//			System.out.println("DeltaWinkelCheckpoint: " + deltaWinkelCheckPoint);
			//Wenn man dem Checkpoint sehr nahe ist, aber nicht direkt darauf ausgerichtet soll abgebremst werden.
			seekDirection = deltaWinkelCheckPoint * info.getMaxAngularAcceleration()/0.785f;
			if((checkPointAbstand < 150) && (Math.abs(deltaWinkelCheckPoint) > 0.785))
			{
					
				if(info.getVelocity().length() > 20f)
				{
					acceleration = -0.25f;
				}
				else
				{
					acceleration = 1f;
				}
				
			}
			//10 Grad
			if(Math.abs(deltaWinkelCheckPoint) < 0.33)
			{
				seekDirection = deltaWinkelCheckPoint * info.getMaxAngularAcceleration()/0.33f;
				
				//Wenn man dem Checkpoint sehr nahe ist, aber nicht direkt darauf ausgerichtet soll abgebremst werden.
				if((checkPointAbstand < 100) && (Math.abs(deltaWinkelCheckPoint) > 0.1))
				{
//						System.out.println("Feinausrichtung!");
					if(info.getVelocity().length() > 5f)
					{
						acceleration = -0.25f;
					}
					else
					{
						acceleration = 0.2f;
					}
				}
			}
		}
		else 
		{
			//Entscheiden ob nach links oder rechts gelenkt wird.
			if(zielAusrichtung > eigeneAusrichtung)
			{
				seekDirection = 1;
				acceleration = -0.25f;
			}
			if(zielAusrichtung < eigeneAusrichtung)
			{
				seekDirection = -1;
				acceleration = -0.25f;
			}			
		}
		
		//Finale Lenkrichtung
		return (float) ((seekDirection - info.getAngularVelocity()));
	}

	//Funktionen
	//Geschwindigkeit verringern, wenn sich das aktuelle Ziel hinter dem Auto befindet.
	private void zielHinterDemAuto()
	{
		//Wenn das Ziel hinter sich hinter dem Auto befindet, verringere die Geschwindigkeit.
		if((zielAusrichtung < eigeneAusrichtung - Math.PI/2) || (zielAusrichtung > eigeneAusrichtung + Math.PI/2))
		{
//			System.out.println("Das Ziel befindet sich hinter mir!");
			if((info.getVelocity().length() > 0.8))
			{
				acceleration = -0.25f;
			}		
			else
			{
				acceleration = 1;
			}
		}
	}
	//Winkel�berlauf korrigieren
	private void winkelBegrenzen()
	{
		//Winkel�berlauf korrigieren
		if(deltaWinkelCheckPoint > Math.PI)
		{
//			System.out.println("Korrigiere Winkel�berlauf.");
			deltaWinkelCheckPoint = (float) (deltaWinkelCheckPoint - 2 * Math.PI);
		}
		if(deltaWinkelCheckPoint < -Math.PI)
		{
//			System.out.println("Korrigiere Winkel�berlauf.");
			deltaWinkelCheckPoint = (float) (deltaWinkelCheckPoint + 2 * Math.PI);
		}
	}
	//Berechne den Abstand von zwei Punkten.
	private float calculateDistance(Point2D.Float startPunkt, Point2D.Float endPunkt)
	{
		return  (float) Math.sqrt(Math.pow(endPunkt.x - startPunkt.x, 2) + Math.pow(endPunkt.y - startPunkt.y, 2));
	}
		
	//Fleeverhalten	
	public void doAvoidingStuff() {
        for (int i = 0; i < obstacles.length; i++)// durch obstacles iterieren
        {
            float obstacleX;
            float obstacleY;
            float distanceObstacle;

            float distanceLeft;
            float distanceRight;


            // Richtungsvektoren zum Auto berechnen
            vectorMiddle = new Vector2f(25, 0);
            rotateVector(eigeneAusrichtung, vectorMiddle);
//            vectorMiddle.rotate(eigeneAusrichtung);
          
            vectorLeft = new Vector2f(15, 0);
//            vectorLeft.rotate(eigeneAusrichtung + Math.toRadians(45));
            rotateVector(eigeneAusrichtung, vectorLeft);
            vectorRight = new Vector2f(15, 0);
//            vectorRight.rotate(eigeneAusrichtung + Math.toRadians(-45));
            rotateVector(eigeneAusrichtung, vectorRight);
            	
            for (int j = 0; j < obstacles[i].xpoints.length; j++)// durch
                                                                    // x-Koordinaten
                                                                    // iterieren
            {

                // Koordinaten des Hindernisses holen.
                obstacleX = obstacles[i].xpoints[j];
                obstacleY = obstacles[i].ypoints[j];

                distanceObstacle = getObstacleDistance(vectorMiddle, obstacleX, obstacleY);

                distanceLeft = getObstacleDistance(vectorLeft, obstacleX, obstacleY);

                distanceRight = getObstacleDistance(vectorRight, obstacleX, obstacleY);

                // Radius vom Hindernis
                if (distanceObstacle < 20) {

                    if (distanceLeft > distanceRight) {
                        direction = 1;
                        System.out.println("avoided left");
                    } else {
                        direction = -1;
                        System.out.println("avoided right");
                    }

                }

            }
        }
    }
	public float flee()
	{
		fleeDirection = 0;
		ausweichVerhaltenAktiv = false;
		a = 1;
		b = 0;
		//Ausweichverhalten
		for(int i = 0;  i < obstacles.length;i++)//durch obstacles iterieren
		{
			float obstacleX;
			float obstacleY;
			float richtungsVektorN�chsterPunktX;
			float richtungsVektorN�chsterPunktY;
			
			for(int j = 0; j < obstacles[i].xpoints.length; j++)//durch x-Koordinaten iterieren
			{
				//Koordinaten des Hindernispunkt holen.
				obstacleX = obstacles[i].xpoints[j];
				obstacleY = obstacles[i].ypoints[j];
				//Richtungsvektoren zum Hindernispunkt berechnen.
				richtungsVektorN�chsterPunktX = obstacleX - autoPos.x;
				richtungsVektorN�chsterPunktY = obstacleY - autoPos.y;
								
				//Abst�nde berechnen.
				abstandZumHindernis =  (float) Math.sqrt(Math.pow(richtungsVektorN�chsterPunktX, 2) + Math.pow(richtungsVektorN�chsterPunktY, 2));
				
				//N�chstgelegenes Hindernis bestimmen.
				if(abstandZumHindernis < kleinsterAbstand)
				{
					kleinsterAbstand = abstandZumHindernis;
					aktuellesHindernisX = obstacleX;
					aktuellesHindernisY = obstacleY;	
				}
				
				//Wenn man sich im Radius befindet und denk Punkt im Blick hat, soll ausgewichen werden. 
				if(abstandZumHindernis < radiusHindernis)
				{
					ausweichVerhaltenAktiv = true;
					//Festlegen des n�chstgelegenen Hindernispunkt.					
					richtungsVektorHindernisX = aktuellesHindernisX - autoPos.x;
					richtungsVektorHindernisY = aktuellesHindernisY - autoPos.y;
					
					//Winkel zwischen eigener Ausrichtung und dem Hindernis berechnen.
					hindernisAusrichtung = (float) Math.atan2(richtungsVektorHindernisX, richtungsVektorHindernisY);					
					eigeneAusrichtung = info.getOrientation();
					deltaWinkelHindernis = (hindernisAusrichtung - eigeneAusrichtung);	
					
					//Wenn der Checkpoint innerhalb des Toleranzbereich ist, lenke dagegen.
					if(Math.abs(deltaWinkelHindernis) < 0.785)		
					{
						fleeDirection = deltaWinkelHindernis * info.getMaxAngularAcceleration()/0.785f;
//						System.out.println("Weiche aus!");
//						if(Math.abs(deltaWinkelHindernis) < 0.33)
//						{
//							fleeDirection = (float) (deltaWinkelHindernis * info.getMaxAngularAcceleration()/0.33);							
//						}
					}
					
//					else 
//					{
//						
//						//Entscheiden ob nach links oder rechts gelenkt wird.
//						if(hindernisAusrichtung > eigeneAusrichtung)
//						{
////							System.out.println("Lenke nach rechts vom Ziel weg!");
//							fleeDirection = 1;//flee nach rechts
//							
//						}
//						if(hindernisAusrichtung < eigeneAusrichtung)
//						{
////							System.out.println("Lenke nach links vom Ziel weg!");
//							fleeDirection = -1;//flee nach links
//						}			
//					}
					
					//Gewichtung berechnen					
					b = (radiusHindernis - kleinsterAbstand) / radiusHindernis;
					a = 1 - b;
					//Finale Gegenlenkrichtung
					fleeDirection = (float) (-(fleeDirection - info.getAngularVelocity()));	
					
				}
				else
				{
			
				}
			}
			
		}
		kleinsterAbstand = 1000;
		return fleeDirection;
	}
	//Abstand vom Vektor zum Hindernis
	public float getObstacleDistance(Vector2f vector, float obstacleX, float obstacleY) {
        float distanceObstacle;
        float distanceX;
        float distanceY;
        distanceX = obstacleX - (vector.getX() + autoPos.x);
        distanceY = obstacleY - (vector.getY() + autoPos.y);

        distanceObstacle = (float) Math.sqrt(Math.pow(distanceX, 2) + Math.pow(distanceY, 2));
        return distanceObstacle;
    }
	
	//Rotate Vektor
	public void rotateVector(double degree, Vector2f myVector)
	{
		float x = myVector.x;
		float y = myVector.y;
//      degree = Math.toRadians(degree);
      float oldX = x;
      x = (float) (x * Math.cos(degree) - y * Math.sin(degree));
      
      y = (float) (oldX * Math.sin(degree) + y * Math.cos(degree));
      
  }
		
	//Zwischen den Eckpunkten des Hindernis werden Punkte berechnet, um das Polygon h�her aufzul�sen.
	public void polygonVerfeinern()
	{
		for(int i = 0;  i < obstacles.length;i++)//durch obstacles iterieren
		{	
			Polygon newObstacle = new Polygon();
			
			//Punkte des alten Polygons ausgeben.
//			System.out.println("Altes Hindernis#" + i);
			//neuen Mittelpunkt berechnen
			for(int j = 0; j < obstacles[i].xpoints.length - 1; j++)
			{
					newObstacle.addPoint(obstacles[i].xpoints[j], obstacles[i].ypoints[j]);
					newObstacle.addPoint((obstacles[i].xpoints[j] + obstacles[i].xpoints[j+1])/2, (obstacles[i].ypoints[j] + obstacles[i].ypoints[j+1])/2);	
					
					//System.out.println("Punkt#" + j + " X: " + obstacles[i].xpoints[j] + " Y: " + obstacles[i].ypoints[j] );
			}
			//letzten Punkt des Obstacle auch noch ausgeben.
			int lastItem = obstacles[i].xpoints.length - 1;
//			System.out.println("Punkt#" + lastItem + " X: " + obstacles[i].xpoints[lastItem] + " Y: " + obstacles[i].ypoints[lastItem] );
			
			//Neuen Mittelpunkt zwischen dem letzten und dem ersten Punkt des Polygons erzeugen. 
			newObstacle.addPoint((obstacles[i].xpoints[obstacles[i].xpoints.length-1] + obstacles[i].xpoints[0])/2, (obstacles[i].ypoints[obstacles[i].xpoints.length-1] + obstacles[i].ypoints[0])/2);
			//Altes obstacle ersetzen
			obstacles[i] = newObstacle;
			
			//Punkte des neuen Polygons ausgeben.
//			System.out.println("Neues Hindernis#" + i);
			for(int h = 0; h < newObstacle.xpoints.length; h++)
			{
//				System.out.println("Punkt#" + h + " X: " + newObstacle.xpoints[h] + " Y: " + newObstacle.ypoints[h] );
			}
		}
	}
	
	// Add own obsticles
	
	private void refineObstacles()
	{
		
		for (int i = 0; i < obstacles.length; i++)// durch obstacles iterieren
		{
			for (int j = 0; j < obstacles[i].xpoints.length; j++)// durch
				// x-Koordinaten
				// iterieren
				
			{
				
				if (j == 0)
					lengthFor = obstacles[i].xpoints.length;
				if (j < lengthFor - 1) {
					
					for (int k = 0; k < seperations; k++) {
						obstacles[i].addPoint(
								(int) ((obstacles[i].xpoints[j + 1] - obstacles[i].xpoints[j]) / seperations * (k + 1))
								+ obstacles[i].xpoints[j],
								(int) ((obstacles[i].ypoints[j + 1] - obstacles[i].ypoints[j]) / seperations * (k + 1))
								+ obstacles[i].ypoints[j]);
						if (j == lengthFor - 2) {
							int indexJ = j + 1;
							obstacles[i].addPoint(
									
									(int) ((obstacles[i].xpoints[0] - obstacles[i].xpoints[indexJ]) / seperations
											* (k + 1)) + obstacles[i].xpoints[indexJ],
									(int) ((obstacles[i].ypoints[0] - obstacles[i].ypoints[indexJ]) / seperations
											* (k + 1)) + obstacles[i].ypoints[indexJ]);
							
						}
					}
					
				}
			}
		}
	}

	public void printAmountOfObstaclePoints()
	{
		int counter = 0; 
		for(int i = 0; i < obstacles.length; i++)
		{
			for(int j = 0; j < obstacles[i].xpoints.length; j++)
			{
				counter++;
			}
		}
		System.out.println("Amount of Vertices in all Obstacles: " + counter);
	}

	
	
	//Drawmethods
	//Graphen zeichnen
	private void drawGraph() 
	{				  
		for (int index = 0; index < myGraph.getVertices().size(); index++) 
		{
			for(int i = 0; i < myGraph.getEdges().size(); i++)
			{
				if(myGraph.getEdges().get(index).get(i) > 0 )
				{
					 Point2D.Float knoten = myGraph.getVertices().get(index).getPosition();
					 Point2D.Float possiblePath = myGraph.getVertices().get(i).getPosition();
					 
					 //Kanten zeichnen
					 GL11.glBegin(GL11.GL_LINES);
					 GL11.glColor3d(0, 1, 0);
					 GL11.glVertex2d(knoten.x, knoten.y);
					 GL11.glVertex2d(possiblePath.x, possiblePath.y);
					 GL11.glEnd();
					 GL11.glPointSize(20);
					 
					 //Knoten zeichnen
					 GL11.glPointSize(10);
					 GL11.glColor3d(0, 0, 1);					  
					 GL11.glBegin(GL11.GL_POINTS);
					 GL11.glVertex2d(knoten.x, knoten.y); 
					 GL11.glEnd();
				}		
				else
				{
//							 Point2D.Float knoten = myGraph.getKnoten().get(index);
//							 Point2D.Float possiblePath = myGraph.getKnoten().get(i);
//							 
//							 GL11.glBegin(GL11.GL_LINES);
//							 GL11.glColor3d(1, 0, 0);
//							 GL11.glVertex2d(knoten.x, knoten.y);
//							 GL11.glVertex2d(possiblePath.x, possiblePath.y);
//							 GL11.glEnd();
				}
			}
		}			
	}

	//Pfad zum Ziel zeichnen.
	private void drawFinalPath() 
	{
				
		if((myAStern.getFinalPath() != null) && (myAStern.getFinalPath().size() != 0))
		{
			for(int index = 0; index < myAStern.getFinalPath().size()-1; index++)
			{
				 Point2D.Float knoten = myAStern.getFinalPath().get(index).getPosition();
				 Point2D.Float knotenNext = myAStern.getFinalPath().get(index+1).getPosition();
				 
				 GL11.glBegin(GL11.GL_LINES);
				 GL11.glColor3d(1, 1, 1);
				 GL11.glVertex2d(knoten.x, knoten.y);
				 GL11.glVertex2d(knotenNext.x, knotenNext.y);
				 GL11.glEnd();			
			}	
		}				
	}

	//Fastzonepunkte zeichnen.
	private void drawFastZonesNodes()
	{
		for(int i = 0; i < myGraph.getNewFastZones().size();  i++)
		{
			for(int j = 0; j < myGraph.getNewFastZones().get(i).size(); j++)
			{
				GL11.glBegin(GL11.GL_POINTS);
				GL11.glPointSize(100);
				GL11.glColor3d(0, 1, 1);			
				float xPos = myGraph.getNewFastZones().get(i).get(j).x;
				float yPos = myGraph.getNewFastZones().get(i).get(j).y;
				GL11.glVertex2d(xPos, yPos); 
				GL11.glEnd();					
			}
		}		
	}
	
	//Slowzonepunkte zeichnen.
	private void drawSlowZonesNodes()
	{
		for(int i = 0; i < myGraph.getNewSlowZones().size();  i++)
		{
			for(int j = 0; j < myGraph.getNewSlowZones().get(i).size(); j++)
			{
				GL11.glBegin(GL11.GL_POINTS);
				GL11.glPointSize(100);
				GL11.glColor3d(1, 0, 0);			
				float xPos = myGraph.getNewSlowZones().get(i).get(j).x;
				float yPos = myGraph.getNewSlowZones().get(i).get(j).y;
				GL11.glVertex2d(xPos, yPos); 
				GL11.glEnd();					
			}
		}		
	}

	private void drawObstacleVertices()
	{
		for(int listIndex = 0; listIndex < obstacles.length; listIndex++)
		{
			for(int pointIndex = 0; pointIndex < obstacles[listIndex].xpoints.length; pointIndex++)
			{
				GL11.glBegin(GL11.GL_POINTS);
				GL11.glPointSize(100);
				GL11.glColor3d(1, 0, 1);			
				float xPos = obstacles[listIndex].xpoints[pointIndex];
				float yPos = obstacles[listIndex].ypoints[pointIndex];
				GL11.glVertex2d(xPos, yPos); 
				GL11.glEnd();				
			}
		}
	}
}
