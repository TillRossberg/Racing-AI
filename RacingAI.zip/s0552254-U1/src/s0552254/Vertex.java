package s0552254;

import java.awt.geom.Point2D;
import java.util.ArrayList;

public class Vertex 
{
	public Vertex(float mySpotNumber, float myX, float myY)
	{
		spotNumber = mySpotNumber;
		position.setLocation(myX, myY);		
	}
	private float spotNumber;
	private float f = 0;
	private float g = 0;
	private float h = 0;
	private Point2D.Float position = new Point2D.Float();	
	private Vertex previousNode = null;
	
	private ArrayList<Vertex> neighbors = new ArrayList<Vertex>();
	
	private boolean isPartOfFinalPath = false;
	private boolean isStartPoint = false;
	private boolean isEndPoint = false;
	private boolean isInOpenSet = false;	
	private boolean isInClosedSet = false;	
	private boolean isInFastZone = false;
	private boolean isInSlowZone = false;
	private int fastZoneIndex;
	private int slowZoneIndex;
	
	
	//Addtional functions.
	public Float[] getSpot()
	{
		Float[] values = new Float[4];
		values [0] = spotNumber;
		values [1] = f;
		values [2] = g;
		values [3] = h;		
		
		return values;
	}

	public void printSpot()
	{
		String zero;
		if(spotNumber < 10){zero = "0"; }else{zero = "";}
		System.out.println("Vertex#"+ zero + (int)(spotNumber) + ": " + " fCost: " + f + " |gCost: " + g + " |hCost: " + h 
													   + " |In openSet: " + isInOpenSet + " |In closedSet: " + isInClosedSet 
													   + " |X: " + position.x + " Y: " + position.y );
		System.out.println();
	}
	
	public void printNeighbors()
	{
		System.out.print("Spot" + spotNumber + " has following neighbors: ");
		for(int i = 0; i < neighbors.size(); i++)
		{			
			System.out.print(neighbors.get(i).getSpotNumber() + "; ");
		}
		System.out.println("");		
	}
	
	public void addNeighbor(Vertex e)
	{
		neighbors.add(e);		
	}
	
	public void removePreviousNode()
	{
		previousNode = null;
	}
	public void printPreviousNode()
	{
		if(previousNode != null)
		{
			System.out.println("Previous Node" + previousNode.getSpotNumberAsInt());
		}		
	}
	
	//Getters
	public float getF() {return f;}	
	public float getG() {return g;}	
	public float getH() {return h;}	
	public boolean isInOpenSet() {return isInOpenSet;}
	public boolean isInClosedSet() {return isInClosedSet;}
	public Point2D.Float getPosition() {return position;}	
	public float getSpotNumber() {return spotNumber;}
	public int getSpotNumberAsInt() {return (int)(spotNumber);}
	public ArrayList<Vertex> getNeighbors() {return neighbors;}
	public Vertex getPreviousNode() {return previousNode;}
	public boolean isStartPoint() {return isStartPoint;}
	public boolean isEndPoint() {return isEndPoint;}
	public boolean isPartOfFinalPath() {return isPartOfFinalPath;}
	public boolean isInFastZone() {return isInFastZone;}
	public boolean isInSlowZone() {return isInSlowZone;}
	public int getFastZoneIndex() {return fastZoneIndex;}
	public int getSlowZoneIndex() {return slowZoneIndex;}

	
	
	//Setters
	public void setF(float f) {this.f = f;}
	public void setG(float g) {this.g = g;}
	public void setH(float h) {this.h = h;}	
	public void setInOpenSet(boolean isInOpenSet) {	this.isInOpenSet = isInOpenSet;}
	public void setInClosedSet(boolean isInClosedSet) {this.isInClosedSet = isInClosedSet;}
	public void setPosition(float x, float y) {this.position.setLocation(x, y);}
	public void setPreviousNode(Vertex previousNode) {this.previousNode = previousNode;}
	public void setIsStartPoint(boolean isStartPoint) {this.isStartPoint = isStartPoint;}
	public void setIsEndPoint(boolean isEndPoint) {this.isEndPoint = isEndPoint;}
	public void setPartOfFinalPath(boolean isPartOfFinalPath) {this.isPartOfFinalPath = isPartOfFinalPath;}
	public void setInSlowZone(boolean isInSlowZone) {this.isInSlowZone = isInSlowZone;}
	public void setInFastZone(boolean isInFastZone) {this.isInFastZone = isInFastZone;}
	public void setFastZoneIndex(int fastZoneIndex) {this.fastZoneIndex = fastZoneIndex;}
	public void setSlowZoneIndex(int slowZoneIndex) {this.slowZoneIndex = slowZoneIndex;}
	
	
	public void removeAllNeighbors() 
	{
		neighbors.clear();
	}
	
}
