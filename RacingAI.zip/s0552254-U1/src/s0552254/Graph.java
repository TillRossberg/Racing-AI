package s0552254;

import java.awt.Polygon;
import lenz.htw.ai4g.ai.AI;
import lenz.htw.ai4g.ai.DriverAction;
import lenz.htw.ai4g.ai.Info;
import s0552254.Vertex;

import java.awt.geom.Area;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Vector;

import org.lwjgl.opengl.GL11;
import org.lwjgl.util.vector.Vector2f;



public class Graph 
{	
	public Graph(Polygon[] hindernisse, Polygon[] fastZones, Polygon[] slowZones)
	{
		obstacles = hindernisse;
		myFastZones = fastZones;		
		mySlowZones = slowZones;				
		createReflexEcken();			
	}
	
	//Der Graph
	private ArrayList<Vertex> vertices = new ArrayList<Vertex>();
	private ArrayList<ArrayList<Float>> edges = new ArrayList<ArrayList<Float>>();

	//Obstacleged�ns
	private float offset = 13f; //Offset, um das die Punkte aus dem alten Polygon geschoben werden.
	private float streifenBreite = 10;//Breite des Streifenpolygons, mit dem die Obstaclekollision festgestellt werden soll. Sorgt daf�r, dass die m�glichen Kanten nicht zu dicht an einem Obstacle sind. 
	
	Polygon[] obstacles;
	Polygon[] myFastZones;
	Polygon[] mySlowZones;
	
	private ArrayList<ArrayList<Point2D.Float>> newFastZones = new ArrayList<ArrayList<Point2D.Float>>();
	private ArrayList<ArrayList<Point2D.Float>> newSlowZones = new ArrayList<ArrayList<Point2D.Float>>();
	private ArrayList<ArrayList<Point2D.Float>> allHulls = new ArrayList<ArrayList<Point2D.Float>>();	
	private ArrayList<ArrayList<Point2D.Float>> allHullsWithOffset = new ArrayList<ArrayList<Point2D.Float>>();
	
	
	
	public void createEmptyGraph() 
	{		
		int spotNumberCounter = 0;//Punkte gleichm��ig durchnummerieren.
		//Koordinaten aller coolen Punkte in die Knoten schreiben.
		for(int i = 0; i < allHullsWithOffset.size(); i++)
		{
			for(int j = 0; j < allHullsWithOffset.get(i).size(); j++)
			{
				float x = allHullsWithOffset.get(i).get(j).x;
				float y = allHullsWithOffset.get(i).get(j).y;
				
				Vertex pointToAdd = new Vertex(spotNumberCounter, x, y);
				vertices.add(pointToAdd);
				spotNumberCounter++;
			}
		}	
		
		if(myFastZones != null)
		{
			fastZonesVerfeinern();
			//Koordinaten aller Fastzones in die Knoten schreiben.
			for(int i = 0; i < newFastZones.size(); i++)
			{
				for(int j = 0; j < newFastZones.get(i).size(); j++)
				{
					float x = newFastZones.get(i).get(j).x;
					float y = newFastZones.get(i).get(j).y;
					
					Vertex pointToAdd = new Vertex(spotNumberCounter, x, y);
					pointToAdd.setInFastZone(true);
					pointToAdd.setFastZoneIndex(i);
					vertices.add(pointToAdd);
					spotNumberCounter++;
				}
			}				
		}
		
		//Koordinaten aller Slowzones in die Knoten schreiben.
		if(mySlowZones != null)
		{
			slowZonesVerfeinern();
			//Koordinaten aller Fastzones in die Knoten schreiben.
			for(int i = 0; i < newSlowZones.size(); i++)
			{
				for(int j = 0; j < newSlowZones.get(i).size(); j++)
				{
					float x = newSlowZones.get(i).get(j).x;
					float y = newSlowZones.get(i).get(j).y;
					
					Vertex pointToAdd = new Vertex(spotNumberCounter, x, y);
					pointToAdd.setInSlowZone(true);
					pointToAdd.setSlowZoneIndex(i);
					vertices.add(pointToAdd);
					spotNumberCounter++;
				}
			}				
		}
		
		//Kantengewichte standarm��ig auf -1 setzen.
		for(int i = 0; i < vertices.size(); i++)
		{
			ArrayList<Float> neueListe = new ArrayList<Float>();//1.Dimension
			edges.add(neueListe);
			for(int j = 0; j < vertices.size(); j++)//2.Dimension
			{
				if(i == j)
				{
					edges.get(i).add(0f);
				}
				else
				{
					edges.get(i).add(-1f);
				}				
			}
		}
	}
	
	//Creates an Adjacencymatrix and fills all positions with -1.
 	public void createEmptyAdjacencyMatrix(int numberOfVertices)
		{
			edges = new ArrayList<ArrayList<Float>>();
			vertices = new ArrayList<Vertex>();
			
			for(int index = 0; index < numberOfVertices; index++)
			{			
				//Initiate edges
				ArrayList<Float> newEdges = new ArrayList<Float>();
				edges.add(newEdges);
				//Initiate vertices
				Vertex myVertex = new Vertex(index, 0f, 0f);
				vertices.add(myVertex);
				
				
				for(int j = 0; j < numberOfVertices; j++)
				{
					if(index == j)
					{
						edges.get(index).add(0f);
					}
					else
					{
						edges.get(index).add(-1f);
					}				
				}
			}
		}
	
	//Teste Punkte auf Sichtbarkeit und berechne ein Kantengewicht, wenn sie sich sehen k�nnen. Init sorgt daf�r, dass nur einmal die Paths f�r alle Knoten berechnet werden, danach nur noch f�r die letzten beiden (Checkpoint und Autoposition.)
	void createPaths()
	{
		//Alte Nachbarn rausschmei�en.
		for(int vertexIndex = 0; vertexIndex < vertices.size(); vertexIndex++)
		{
			vertices.get(vertexIndex).removeAllNeighbors();
		}
		for(int vertexIndex = 0; vertexIndex < vertices.size(); vertexIndex++)
		{	
			Vertex referenzPunkt = vertices.get(vertexIndex);//Hole einen Punkt...
			Vertex testPunkt;
			
			for(int edgeIndex = vertexIndex + 1; edgeIndex < vertices.size(); edgeIndex++)//...und hole alle anderen Punkte...
			{
				boolean obstacleIntersection = false;
				boolean fastZoneIntersection = false;
				boolean slowZoneIntersection = false;
				testPunkt = vertices.get(edgeIndex);
				Polygon myLinePolygon = createLinePolygon(referenzPunkt, testPunkt, streifenBreite);//...und erstelle ein Linienpolygon.			
				
				//Durch alle obstacles iterieren...	
				for(int k = 0; k < obstacles.length; k++)
				{
					if(testIntersection(myLinePolygon, obstacles[k]))//...und testen, ob sie das Linepolygon schneiden.
					{
						obstacleIntersection = true;
						break;//Stoppt die for-Schleife wenn dies eintritt
					}					
				}	
				if(mySlowZones != null)
				{
					//Durch alle slowZones iterieren...	
					for(int k = 0; k < mySlowZones.length; k++)
					{
						if(testIntersection(myLinePolygon, mySlowZones[k]))//...und testen, ob sie das Linepolygon schneiden.
						{
							slowZoneIntersection = true;
							break;//Stoppt die for-Schleife wenn dies eintritt
						}					
					}						
				}				
				
				if(!obstacleIntersection)
				{
					//Wenn beide Punkte teil derselben Fastzone sind, wird das Gewicht halbiert.
					if(referenzPunkt.isInFastZone() && testPunkt.isInFastZone() && (referenzPunkt.getFastZoneIndex() == testPunkt.getFastZoneIndex()))
					{
						//Kantengewichte halbieren, da man doppelt so schnell f�hrt.
						float distance = (float) (0.5 * calcDistance(referenzPunkt.getPosition(), testPunkt.getPosition()));
						edges.get(vertexIndex).set(edgeIndex, distance);
						edges.get(edgeIndex).set(vertexIndex, distance);
						//Nachbarn anf�gen
						testPunkt.addNeighbor(referenzPunkt);
						referenzPunkt.addNeighbor(testPunkt);
					}
					else if(referenzPunkt.isInSlowZone() && testPunkt.isInSlowZone() && (referenzPunkt.getSlowZoneIndex() == testPunkt.getSlowZoneIndex()))
					{
						//Kantengewichte halbieren, da man doppelt so schnell f�hrt.
						float distance = (float) (4 * calcDistance(referenzPunkt.getPosition(), testPunkt.getPosition()));
						edges.get(vertexIndex).set(edgeIndex, distance);
						edges.get(edgeIndex).set(vertexIndex, distance);
						//Nachbarn anf�gen
						testPunkt.addNeighbor(referenzPunkt);
						referenzPunkt.addNeighbor(testPunkt);
					}
					else if(slowZoneIntersection)//PL�D
					{
//						//Kantengewichte setzen.
//						float distance = 4 * calcDistance(referenzPunkt.getPosition(), testPunkt.getPosition());
//						edges.get(vertexIndex).set(edgeIndex, distance);
//						edges.get(edgeIndex).set(vertexIndex, distance);
//						//Nachbarn anf�gen
//						testPunkt.addNeighbor(referenzPunkt);
//						referenzPunkt.addNeighbor(testPunkt);		
						
						
					}
					else
					{
						//Kantengewichte setzen.
						float distance = calcDistance(referenzPunkt.getPosition(), testPunkt.getPosition());
						edges.get(vertexIndex).set(edgeIndex, distance);
						edges.get(edgeIndex).set(vertexIndex, distance);
						//Nachbarn anf�gen
						testPunkt.addNeighbor(referenzPunkt);
						referenzPunkt.addNeighbor(testPunkt);						
					}
				}				
			}			 
		}		
	}
	
	//Schmeisst alle Kanten vom Checkpoint und der Autoposition raus.
	public void clearCarTargetEdges() 
	{

		for (int i = 0; i < edges.size(); i++) 
		{
			edges.get(i).set(vertices.size() - 1 , -1f);
			edges.get(vertices.size() - 1).set( i, -1f);
			edges.get(i).set(vertices.size() - 2 , -1f);
			edges.get(vertices.size() - 2).set( i, -1f);
		}
	}

	//Graham scan f�r alle obstacles.
	public void createReflexEcken()	
	{		
		for(int i = 0; i< obstacles.length; i++)//Durch alle obstacles iterieren...
		{
			ArrayList<Point2D.Float> convexHull = new ArrayList<Point2D.Float>();
			
			for(int j = 0; j < obstacles[i].xpoints.length; j++)//...und die Koordinaten in eine Liste schreiben...
			{
				Point2D.Float point = new Point2D.Float(0,0);
				point.setLocation(obstacles[i].xpoints[j] , obstacles[i].ypoints[j]);				
				convexHull.add(point);
//				System.out.println("X" + j + ": " + point.getX() + " Y" + j + ": " + point.getY());
			}
			
			//... auf die wir den Graham Scan anwenden. Wenn C auf der rechten Seite der Strecke AB liegt, wird die Determinante <= 0. Cool! Wenn nicht, raus mit dem Punkt.
			int h = 0;
			while( h < convexHull.size() )
			{
				Point2D.Float A = new Point2D.Float(0,0);//Anfangspunkt der Strecke
				Point2D.Float B = new Point2D.Float(0,0);//Endpunkt der Strecke
				Point2D.Float C = new Point2D.Float(0,0);//Zu �berpr�fender Punkt				
				float determinanteABC = 0;				
				
				C.setLocation(convexHull.get(h).getX(), convexHull.get(h).getY());				
				
				if(h == 0)//Beim ersten Punkt, ist der vorhergehnde Punkt der letzte in der Liste.
				{				
					A.setLocation(convexHull.get(convexHull.size()-1).getX(), convexHull.get(convexHull.size()-1).getY());
					B.setLocation(convexHull.get(h+1).getX(), convexHull.get(h+1).getY());				
					determinanteABC =  (B.x - A.x)*(C.y - A.y) - (C.x - A.x)*(B.y - A.y);	
				}
				else if(h == convexHull.size()-1)//Beim letzten Punkt, ist der nachfolgende Punkt der erste in der Liste.
				{
					A.setLocation(convexHull.get(h-1).getX(), convexHull.get(h-1).getY());
					B.setLocation(convexHull.get(0).getX(), convexHull.get(0).getY());				
					determinanteABC =  (B.x - A.x)*(C.y - A.y) - (C.x - A.x)*(B.y - A.y);
				}
				else//Ansonsten den nachfolgenden und vorherliegenden Punkt zur Berechnung verwenden.
				{
					A.setLocation(convexHull.get(h-1).getX(), convexHull.get(h-1).getY());
					B.setLocation(convexHull.get(h+1).getX(), convexHull.get(h+1).getY());				
					determinanteABC = (B.x - A.x)*(C.y - A.y) - (C.x - A.x)*(B.y - A.y);
				}			
						
				if(determinanteABC <= 0)//Punkt is cool!
				{			
					//Offset draufrechnen.
					convexHull.get(h).setLocation(createPointWithOffset(A, B, C));
					h += 1;
				}
				else//Punkt is nich cool!
				{
//					System.out.println("Entferne Punkt: X: " + convexHull.get(h).getX() + " Y: " + convexHull.get(h).getY() + " mit Skalarprodukt: " + determinanteABC);
					
					convexHull.remove(h);
					
					h -= 1;
					if(h<0)
					{
						h = 0;
					}
				}				
			}			
			//Zum Schluss die aktuelle H�lle zu allen bisherigen konvexen H�llen addieren.
			allHullsWithOffset.add(convexHull);
		}		
	}
	
	//Schiebt den Punkt ein St�ck vom Zentrum des Polygons weg.
	private Point2D.Float createPointWithOffset(Point2D.Float a,Point2D.Float b,Point2D.Float c) 
	{		
		//Vektor von C nach A und...
		Vector2f CA = new Vector2f(a.x - c.x, a.y - c.y);
		//...Vektor von C nach B...
		Vector2f CB = new Vector2f(b.x - c.x, b.y - c.y);	
		//...werden normalisiert...
		CA.normalise();
		CB.normalise();
		//... und addiert und ums Offset verschoben ...
		Vector2f CAandCB = new Vector2f();
		Vector2f.add(CA, CB, CAandCB);
		CAandCB.normalise();	
		CAandCB.scale(offset);
		//...negiert, damit er in die richtige Richtung zeigt
		CAandCB.negate();		
		//...und auf den Punkt draufgerechnet.
		return new Point2D.Float(c.x + CAandCB.x, c.y + CAandCB.y);		
	}
	
	//Verfeinert die Slow- und Fastzones um weitere Punkte
	private void fastZonesVerfeinern()
	{
		for(int listIndex = 0; listIndex < myFastZones.length; listIndex++)
		{
			ArrayList<Point2D.Float> listToAdd = new ArrayList<Point2D.Float>();
			newFastZones.add(listToAdd);
			Point2D.Float A = new Point2D.Float();//Current point
			Point2D.Float B = new Point2D.Float();//Next point
			
			//Alle Eckpunkte der alten Fastzone, zur neuen Hinzuf�gen.
			for(int pointIndex = 0; pointIndex < myFastZones[listIndex].xpoints.length; pointIndex++)
			{
				float offset = 10f;
				Point2D.Float point = new Point2D.Float(0,0);
				if(pointIndex == 0)
				{
					point.setLocation(myFastZones[listIndex].xpoints[pointIndex] + offset, myFastZones[listIndex].ypoints[pointIndex] + offset);		
				}
				if(pointIndex == 1)
				{
					point.setLocation(myFastZones[listIndex].xpoints[pointIndex] - offset, myFastZones[listIndex].ypoints[pointIndex] + offset);
				}
				if(pointIndex == 2)
				{
					point.setLocation(myFastZones[listIndex].xpoints[pointIndex] - offset, myFastZones[listIndex].ypoints[pointIndex] - offset);
				}
				if(pointIndex == 3)
				{
					point.setLocation(myFastZones[listIndex].xpoints[pointIndex] + offset, myFastZones[listIndex].ypoints[pointIndex] - offset);
				}			
						
				newFastZones.get(listIndex).add(point);
			}
			//Positionen f�r die Zwischenpunkte berechnen und...
			for(int pointIndex = 0; pointIndex < myFastZones[listIndex].xpoints.length-1; pointIndex++)
			{
				A.setLocation(myFastZones[listIndex].xpoints[pointIndex], myFastZones[listIndex].ypoints[pointIndex]);
				B.setLocation(myFastZones[listIndex].xpoints[pointIndex+1], myFastZones[listIndex].ypoints[pointIndex+1]);
				
				//Calculate coordinates of the additional points.
				Point2D.Float newPoint01 = new Point2D.Float(0,0);
				newPoint01.x = A.x + ((B.x - A.x) * 1/3);
				newPoint01.y = A.y + ((B.y - A.y) * 1/3);
				newFastZones.get(listIndex).add(newPoint01);	
				Point2D.Float newPoint02 = new Point2D.Float(0,0);
				newPoint02.x = A.x + ((B.x - A.x) * 2/3);
				newPoint02.y = A.y + ((B.y - A.y) * 2/3);
				newFastZones.get(listIndex).add(newPoint02);		
			}
			//...den letzten Punkt nicht vergessen
			A.setLocation(myFastZones[listIndex].xpoints[myFastZones[listIndex].xpoints.length-1], myFastZones[listIndex].ypoints[myFastZones[listIndex].ypoints.length-1]);
			B.setLocation(myFastZones[listIndex].xpoints[0], myFastZones[listIndex].ypoints[0]);
			//Calculate coordinates of the additional points.
			Point2D.Float newPoint01 = new Point2D.Float(0,0);
			newPoint01.x = A.x + ((B.x - A.x) * 1/3);
			newPoint01.y = A.y + ((B.y - A.y) * 1/3);
			newFastZones.get(listIndex).add(newPoint01);
			Point2D.Float newPoint02 = new Point2D.Float(0,0);
			newPoint02.x = A.x + ((B.x - A.x) * 2/3);
			newPoint02.y = A.y + ((B.y - A.y) * 2/3);
			newFastZones.get(listIndex).add(newPoint02);					
		}
	}
	private void slowZonesVerfeinern()
	{
		for(int listIndex = 0; listIndex < mySlowZones.length; listIndex++)
		{
			ArrayList<Point2D.Float> listToAdd = new ArrayList<Point2D.Float>();
			newSlowZones.add(listToAdd);
			Point2D.Float A = new Point2D.Float();//Current point
			Point2D.Float B = new Point2D.Float();//Next point
			
			//Alle Eckpunkte der alten Slowzone, zur neuen Hinzuf�gen.
			for(int pointIndex = 0; pointIndex < mySlowZones[listIndex].xpoints.length; pointIndex++)
			{
				float offset = 10f;
				Point2D.Float point = new Point2D.Float(0,0);
				if(pointIndex == 0)
				{
					point.setLocation(mySlowZones[listIndex].xpoints[pointIndex] + offset, mySlowZones[listIndex].ypoints[pointIndex] + offset);		
				}
				if(pointIndex == 1)
				{
					point.setLocation(mySlowZones[listIndex].xpoints[pointIndex] - offset, mySlowZones[listIndex].ypoints[pointIndex] + offset);
				}
				if(pointIndex == 2)
				{
					point.setLocation(mySlowZones[listIndex].xpoints[pointIndex] - offset, mySlowZones[listIndex].ypoints[pointIndex] - offset);
				}
				if(pointIndex == 3)
				{
					point.setLocation(mySlowZones[listIndex].xpoints[pointIndex] + offset, mySlowZones[listIndex].ypoints[pointIndex] - offset);
				}			
						
				newSlowZones.get(listIndex).add(point);
			}
			//Positionen f�r die Zwischenpunkte berechnen und...
			for(int pointIndex = 0; pointIndex < mySlowZones[listIndex].xpoints.length-1; pointIndex++)
			{
				A.setLocation(mySlowZones[listIndex].xpoints[pointIndex], mySlowZones[listIndex].ypoints[pointIndex]);
				B.setLocation(mySlowZones[listIndex].xpoints[pointIndex+1], mySlowZones[listIndex].ypoints[pointIndex+1]);
				
				//Calculate coordinates of the additional points.
				Point2D.Float newPoint01 = new Point2D.Float(0,0);
				newPoint01.x = A.x + ((B.x - A.x) * 1/3);
				newPoint01.y = A.y + ((B.y - A.y) * 1/3);
				newSlowZones.get(listIndex).add(newPoint01);	
				Point2D.Float newPoint02 = new Point2D.Float(0,0);
				newPoint02.x = A.x + ((B.x - A.x) * 2/3);
				newPoint02.y = A.y + ((B.y - A.y) * 2/3);
				newSlowZones.get(listIndex).add(newPoint02);		
			}
			//...den letzten Punkt nicht vergessen
			A.setLocation(mySlowZones[listIndex].xpoints[mySlowZones[listIndex].xpoints.length-1], mySlowZones[listIndex].ypoints[mySlowZones[listIndex].ypoints.length-1]);
			B.setLocation(mySlowZones[listIndex].xpoints[0], mySlowZones[listIndex].ypoints[0]);
			//Calculate coordinates of the additional points.
			Point2D.Float newPoint01 = new Point2D.Float(0,0);
			newPoint01.x = A.x + ((B.x - A.x) * 1/3);
			newPoint01.y = A.y + ((B.y - A.y) * 1/3);
			newSlowZones.get(listIndex).add(newPoint01);
			Point2D.Float newPoint02 = new Point2D.Float(0,0);
			newPoint02.x = A.x + ((B.x - A.x) * 2/3);
			newPoint02.y = A.y + ((B.y - A.y) * 2/3);
			newSlowZones.get(listIndex).add(newPoint02);					
		}
	}
	
//Additional functions
	//Testet, ob sich zwei Polygone schneiden. Gibt true zur�ck, wenn sie sich schneiden.
	public boolean testIntersection(Polygon polygonA, Polygon polygonB) 
	{
	   Area areaA = new Area(polygonA);
	   areaA.intersect(new Area(polygonB));	   
	   return !areaA.isEmpty();
	}
	
	//Pr�ft die Schnittmenge von Weg und slowZone und rechnet den Anteil der Verlangsamung auf die Wegkosten.
	public float calcSlowZoneRatio(Polygon linePolygon, Polygon slowZonePolygon) 
	{		
	   Area lineArea = new Area(linePolygon);//Fl�che des Linepolygons.
	   Area slowArea = new Area(slowZonePolygon);//Fl�che der Slowzone.
	   Area intersection = new Area (linePolygon);//Schnittmenge der beiden.
	   
	   intersection.intersect(slowArea);
	   return 0f;   
	   
	}
	
	//Erzeugt ein Polygon, um den gew�nschten vektor mit festgelegter Breite.
	private Polygon createLinePolygon(Vertex startPunkt, Vertex endPunkt, float breite)
	{
		Polygon linePolygon = new Polygon();
		Vector2f richtungsVektor = new Vector2f();
		Vector2f senkrechterVektor = new Vector2f();
		//Richtungsvektor zwischen Start- und Endpunkt erstellen...
		richtungsVektor.set(endPunkt.getPosition().x - startPunkt.getPosition().x, endPunkt.getPosition().y - startPunkt.getPosition().y);
		//...diesen senkrecht stellen...
		senkrechterVektor.set(richtungsVektor.y, - richtungsVektor.x);
		
		if(senkrechterVektor.length() != 0)
		{
			//...normieren...
			senkrechterVektor.normalise();
		}
		
		//...um die gew�nschte Streifenbreite verl�ngern...
		senkrechterVektor.scale(streifenBreite/2);
		//...und letztendlich das Streifenpolygon erstellen.
		
		linePolygon.addPoint((int)(startPunkt.getPosition().x + senkrechterVektor.x), (int)(startPunkt.getPosition().y + senkrechterVektor.y));
		linePolygon.addPoint((int)(startPunkt.getPosition().x - senkrechterVektor.x), (int)(startPunkt.getPosition().y - senkrechterVektor.y));
		linePolygon.addPoint((int)(endPunkt.getPosition().x - senkrechterVektor.x), (int)(endPunkt.getPosition().y - senkrechterVektor.y));
		linePolygon.addPoint((int)(endPunkt.getPosition().x - senkrechterVektor.x), (int)(endPunkt.getPosition().y + senkrechterVektor.y));
		
		return linePolygon;
	}
	
	
	//Berechnet den euklidischen Abstand zwischen Start- und Endpunkt.
	public float calcDistance(Point2D.Float start, Point2D.Float end)
	{
		float differenceX = end.x - start.x;
		float differenceY = end.y - start.y;
		float distance = (float) Math.sqrt(differenceX*differenceX + differenceY * differenceY);
		return distance;	
	}	
	
	//Add or remove a vertex.
	public void removeVertex(int i) 
	{
		vertices.remove(i);		
	}
	
	public void addVertex(float autoX, float autoY) 
	{
		//Den neuen Vertex hinzuf�gen.
		Vertex myPoint = new Vertex(vertices.size(),autoX, autoY);		
		vertices.add(myPoint);		

		//Eine neue Liste an die Edges anf�gen und...
		ArrayList<Float> neueListe = new ArrayList<Float>();
		edges.add(neueListe);
		//...diese Liste mit -1 f�llen. An der eigenen Position wird eine 0 einfgef�gt.
		for(int i = 0; i < vertices.size() - 1; i++)
		{
			edges.get(myPoint.getSpotNumberAsInt()).add(-1f);
			edges.get(i).add(-1f);
		}
		edges.get(myPoint.getSpotNumberAsInt()).add(0f);
		System.out.println("F�ge " + myPoint.getSpotNumberAsInt() + " den Vertices hinzu.");		
	}	
	
	//Printmethods
	//Inhalt aller vertices ausgeben.
	public void printVertices(ArrayList<Vertex> vertexList)
 	{
 		for(Vertex index : vertexList)
 		{
 			index.printSpot();
 		}
 	}
	//Prints the Adjacency Matrix (ArrayList).
	public void printAdjacencyMatrixForArrayList(ArrayList<ArrayList<Float>> matrix)
	{
		//Kopfzeile
		System.out.print("     ");
		for(int index = 0; index < matrix.size(); index++ )	
		{
			if(index < 10)
			{
				System.out.print("|\t" + "#0" + index + "\t|");
			}
			else
			{
				System.out.print("|\t" + "#" + index + "\t|");
			}	
		}
		System.out.println("");
		//Unterstriche
		for(int index = 0; index < matrix.size(); index++ )	
		{
			System.out.print("----------------");
		}
		System.out.println("");
		//Zeilenanfang
		for(int j = 0; j < matrix.size(); j++)
		{
			if(j < 10)
			{
				System.out.print("#0" + j + ": ");
			}
			else
			{
				System.out.print("#" + j + ": ");
			}
			//Spalteneintr�ge
			for(int k = 0; k < matrix.get(j).size(); k++)
			{
				System.out.print("|\t" + matrix.get(j).get(k).intValue() + "\t|");
			}
			System.out.println("");
		}
	}
	//Gibt die Nachbarn aller Vertices aus.
	public void printNeighborsForAllVertices(ArrayList<Vertex> vertexList)
	{
		for(int i = 0; i < vertexList.size(); i++)
		{
			vertexList.get(i).printNeighbors();
		}
	}

	
		
	//Getters and Setters
	public ArrayList<Vertex> getVertices() {return vertices;}
	public ArrayList<ArrayList<Float>> getEdges() {return edges;}
	public ArrayList<ArrayList<Point2D.Float>> getAllHullsWithOffset(){return allHullsWithOffset;}
	public ArrayList<ArrayList<Point2D.Float>> getNewFastZones() {return newFastZones;}
	public ArrayList<ArrayList<Point2D.Float>> getNewSlowZones() {return newSlowZones;}	
	
}

